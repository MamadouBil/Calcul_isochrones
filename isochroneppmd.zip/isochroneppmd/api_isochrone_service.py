# Fichier : api_isochrone_service.py
import requests
import urllib.parse
import json
from typing import Dict, List
from .isochrone_parameters import IsochroneParameters
from qgis.utils import iface 
from qgis.core import QgsPointXY

class ConnectionError(Exception):
    """Exception personnalisée pour les erreurs de communication API/Réseau."""
    pass

class ApiIsochroneService:
    """
    Gère la construction de l'URL, l'exécution de la requête HTTP et la gestion des erreurs.
    """
    # URL de base pour l'API navigation/isochrone du Géoportail
    BASE_URL_NAVIGATION = "https://data.geopf.fr/navigation/isochrone" 
    TIMEOUT_SECONDS = 45 

    # Valeur exacte requise pour l'accès à la librairie (format standard de l'IGN)
    GP_ACCESS_LIB = "3.4.2" 

    def __init__(self):
        pass

    def get_isochrone(self, params: IsochroneParameters) -> Dict: 
        """
        Construit l'URL, exécute la requête API et retourne la réponse JSON décodée (Dict).
        """
        
        # --- Étape 1 : Construction de la chaîne de contraintes (toujours présente) ---
        constraints_value = "" 
        
        if params.constraints_list:
            # S'il y a des contraintes, on les sérialise et les encode
            json_strings = [json.dumps(obj, separators=(',', ':')) for obj in params.constraints_list]
            constraints_raw_value = "|".join(json_strings)
            constraints_value = urllib.parse.quote(constraints_raw_value)
        
        # Le fragment d'URL pour les contraintes est TOUJOURS créé (vide ou plein)
        constraints_param = f"&constraints={constraints_value}" 
        
        
        # --- Étape 2 : Création de la chaîne de requête complète et DYNAMIQUE ---
        
        # Les autres paramètres sont listés ici, SANS 'point'
        ordered_params_for_api = [
            ('gp-access-lib', self.GP_ACCESS_LIB),
            ('resource', params.bdtopo_name), # bdtopo-valhalla ou bdtopo-pgr
            ('direction', params.direction),
            ('costType', params.cost_type),
            ('costValue', params.cost_value), 
            ('profile', params.profile),
            ('timeUnit', 'second'), 
            ('distanceUnit', 'meter'), 
            ('crs', params.crs),
        ]
        
        # Encodage des paramètres standard
        other_params_query = urllib.parse.urlencode(ordered_params_for_api)
        
        # CORRECTION CLÉ : Le paramètre 'point' est inséré manuellement (virgule non encodée)
        point_param = f"point={params.point}"
        
        # Construction de l'URL finale: point, puis le reste des paramètres, puis les contraintes
        full_url = f"{self.BASE_URL_NAVIGATION}?{point_param}&{other_params_query}{constraints_param}" 
        
        print (full_url)
        try:
            # Exécution de la requête HTTP
            response = requests.get(full_url, timeout=self.TIMEOUT_SECONDS) 
            response.raise_for_status() 

            raw_response_data = response.json()
            
            if 'geometry' not in raw_response_data or not raw_response_data['geometry']:
                raise Exception("Réponse API valide, mais aucune géométrie retournée (point peut-être inaccessible).")
                
            return raw_response_data 
            
        except requests.exceptions.HTTPError as e:
            status_code = response.status_code
            error_msg = f"Erreur HTTP {status_code}. Vérifiez les paramètres de requête."
            
            details = 'Détails inconnus.'
            try:
                # Tente de récupérer les détails de l'erreur JSON
                details = response.json().get('error', {}).get('message', 'Détails inconnus.')
            except json.JSONDecodeError:
                pass
            
            # NOUVELLE LOGIQUE : Message spécifique pour "No path found" / Point hors zone
            if status_code == 404 and "No path found" in details:
                # Message convivial pour l'utilisateur
                user_friendly_msg = "Le point sélectionné est probablement hors de la zone de couverture (France métropolitaine ou Corse) de la BD Topo"
                raise ConnectionError(user_friendly_msg) from e
                
            # Si c'est une autre erreur HTTP, retourne le message technique
            error_msg += f" Détails: {details}"
            raise ConnectionError(error_msg) from e

        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Erreur réseau ou timeout lors de l'appel API. Détails: {e}") from e
        

    #Autocomplétion

    def autocomplete_address(self, search_text: str) -> List[str]:
        """
        Appelle l'API de COMPLÉTION (IGN) pour obtenir une liste de suggestions d'adresses.
        """
        # URL standard et éprouvée pour la complétion/autocomplétion IGN.
        # Nous allons utiliser le chemin le plus simple et laisser l'API déterminer l'opération.

        #AUTOCOMPLETE_URL = "https://data.geopf.fr/geocodage/completion/completion"

        AUTOCOMPLETE_URL = "https://data.geopf.fr/geocodage/completion"

        
        params = {
            'text': search_text,     
            'maximumResponses': 8,   
            # Nous allons réintroduire le filtre pour les adresses, car "paris" devrait en trouver
            'type': 'StreetAddress' 
        }
        
        # --- POINT DE DÉBOGAGE CRITIQUE : Juste avant l'appel réseau ---
        print(f"DEBUG API PRE-CALL: Tentative de complétion pour: '{search_text}'")
        # -------------------------------------------------------------
        
        try:
            response = requests.get(AUTOCOMPLETE_URL, params=params, timeout=self.TIMEOUT_SECONDS)
            
            # Si l'appel réussi, affiche l'URL finale et le statut
            print(f"DEBUG API: URL Complétion utilisée: {response.url}")
            print(f"DEBUG API: Statut HTTP: {response.status_code}")

            # Étape 1 : Vérification du statut HTTP
            response.raise_for_status() 

            # Étape 2 : Décodage du JSON
            data = response.json()

            raw_results = data
            
            # Mais parfois, l'API encapsule la liste dans une clé 'features' ou autre
            if isinstance(data, dict) and 'features' in data:
                raw_results = data.get('features', [])
            elif isinstance(data, dict) and 'results' in data:
                 raw_results = data.get('results', [])
            
            # --- DÉBOGAGE : Que traitons-nous comme résultats ? ---
            print(f"DEBUG API: Type de données traitées: {type(raw_results)}")
            
            suggestions: List[str] = []
            
            if raw_results and isinstance(raw_results, list): 
                print(f"DEBUG API: Nombre d'objets à parser: {len(raw_results)}")
                for result in raw_results:
                    # Tenter d'extraire 'fulltext' (le plus probable) ou 'label' (le second plus probable)
                    suggestion_text = result.get('fulltext') 
                    
                    if not suggestion_text:
                        suggestion_text = result.get('label') 

                    if suggestion_text:
                        suggestions.append(suggestion_text)
            
            # --- DÉBOGAGE : Résultat final ---
            print(f"DEBUG API: Suggestions extraites: {suggestions}")
            # ---------------------------------
            
            return suggestions
            
        except requests.exceptions.HTTPError as e:
            # Afficher l'erreur HTTP spécifique
            error_msg = f"Erreur HTTP {response.status_code}. Vérifiez les paramètres de l'API (ex: text non valide)."
            raise ConnectionError(error_msg) from e
        except requests.exceptions.RequestException as e:
            # Erreur réseau (DNS, timeout, etc.)
            raise ConnectionError(f"Erreur réseau/timeout lors de l'autocomplétion. Détails: {e}") from e
        except Exception as e:
            # Autres erreurs (ex: JSON invalide)
            raise ConnectionError(f"Erreur inattendue dans la réponse d'autocomplétion: {e}") from e
        
    
    # Méthode de géocodage direct en utilisant l'API de l'IGN

    def geocode_address(self, address_text: str) -> QgsPointXY or None:
        """
        Appelle l'API de Géocodage (search) pour convertir une adresse en coordonnées (lon, lat).
        """
        GEOCODE_URL = "https://data.geopf.fr/geocodage/search" 
        
        params = {
            'q': address_text, 
            'limit': 1,        
            'index': 'address',
        }
        
        try:
            response = requests.get(GEOCODE_URL, params=params, timeout=self.TIMEOUT_SECONDS)
            response.raise_for_status()
            data = response.json()

            if data and data.get('features') and len(data['features']) > 0:
                coords = data['features'][0]['geometry']['coordinates']
                lon, lat = coords[0], coords[1]
                
                return QgsPointXY(lon, lat)
            
            return None 
            
        except requests.exceptions.HTTPError as e:
            raise ConnectionError(f"Erreur HTTP lors du géocodage: {response.status_code}. Vérifiez les paramètres de requête.") from e
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Erreur réseau ou timeout lors du géocodage. Détails: {e}") from e
        except Exception as e:
            raise ConnectionError(f"Erreur inattendue dans la réponse de géocodage: {e}") from e
        