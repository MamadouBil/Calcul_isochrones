# Fichier : isochroneppmd_dialog.py

from PyQt5.QtWidgets import QDialog, QMessageBox,QCompleter
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsField,
    QgsCoordinateReferenceSystem, 
    QgsCoordinateTransform
)
from qgis.PyQt.QtCore import QVariant 
from qgis.utils import iface
from qgis.gui import QgsMapToolEmitPoint 
from typing import List, Dict, Tuple
import urllib.parse 
import json 
from PyQt5 import QtCore, QtGui

# CORRECTION CLÉ : Utiliser le nom exact de la classe générée
from .isochroneppmd_dialog_base import Ui_isochroneppmdDialogBase 

from .isochrone_parameters import IsochroneParameters
from .api_isochrone_service import ApiIsochroneService, ConnectionError 


# CORRECTION CLÉ : Hériter du nom exact de la classe générée
class IsochroneDialog(QDialog, Ui_isochroneppmdDialogBase):
    
    def __init__(self, iface, parent=None): 
        super(IsochroneDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.api_service = ApiIsochroneService()
        self.point_tool = None 

        #création d'un style pour les menus déroulants
        style = """
        QComboBox::item:hover {
            color: black; 
            background-color: lightgray; 
        }
        QComboBox::item:selected {
            color: black; 
            background-color: white; 
        }
        QComboBox {
            selection-color: black; 
        }
        """
        # désactivation des choix d'isochrone ou d'isodistance au lancement du plugin
        # self.groupBox_4 pour Temps (isochrone), self.groupBox_5 pour Distance (isodistance)
        self.groupBox_4.setEnabled(False) 
        self.groupBox_5.setEnabled(False) 

        #Application du style au menu déroulant
        self.comboBox.setStyleSheet(style)
        self.comboBox_2.setStyleSheet(style)
        self.comboBox_3.setStyleSheet(style)

        # NOUVELLE CONNEXION : Bouton de réinitialisation
        self.pushButton_3.clicked.connect(self.reset_configuration)

        # AJOUT : Définition de l'infobulle pour le bouton de sélection du point
        self.pushButton_2.setToolTip("Cliquez pour sélectionner le point sur la carte")

        # AJOUT : Définition de l'infobulle pour la recherche d'adresse
        self.lineEdit_2.setToolTip("Ici, saisissez l'adresse du point")

        # AJOUT : Définition de l'infobulle pour la saisie des coordonnées (lon/lat) du point
        self.lineEdit.setToolTip("Ici, renseignez les coordonnées (lon/lat) du point")

        #Création des signaux
        self.pushButton.clicked.connect(self.run_isochrone_calculation) 
        self.pushButton_2.clicked.connect(self.select_point_on_map) 

        # NOUVEAU : Connexion des signaux pour les RadioButtons (Isochrone/Isodistance)
        self.radioButton_4.toggled.connect(self.toggle_time_distance_groups)
        self.radioButton_5.toggled.connect(self.toggle_time_distance_groups)

        # Ajout des éléments de menus déroulant
        self.comboBox.addItems(['car', 'pedestrian']) 
        self.comboBox_2.addItems(['Départ', 'Arrivée'])
        self.comboBox_3.addItems(['bdtopo-valhalla', 'bdtopo-pgr']) 
        
        # Définir Isochrone par défaut (et initialiser l'état des groupes)
        self.radioButton_4.setChecked(False) 
        self.toggle_time_distance_groups()

    

        # Initialisation du QCompleter
        self.completer = QCompleter(self)
        self.completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.completer.setFilterMode(QtCore.Qt.MatchContains)
        
        # 🚨 CORRECTION CLÉ 1 : Lier le Completer à lineEdit_2 (le champ d'adresse)
        # self.lineEdit_2 doit exister dans Ui_isochroneppmdDialogBase !
        self.lineEdit_2.setCompleter(self.completer)

        
        # --- CONNEXIONS POUR GÉOCODAGE ET AUTO-COMPLÉTION ---
        
        # 1. Autocomplétion (au fur et à mesure de la saisie)
        # 🚨 CORRECTION CLÉ 2 : Utiliser lineEdit_2 pour l'autocomplétion
        self.lineEdit_2.textChanged.connect(self.suggest_addresses) 
        
        # 2. Géocodage final (après sélection)
        self.completer.activated.connect(self.search_address_after_completion)
        
        # 3. Géocodage si l'utilisateur appuie sur Entrée dans lineEdit_2 (saisie manuelle)
        self.lineEdit_2.returnPressed.connect(self.search_address_from_lineEdit_2)

        # Si l'utilisateur modifie les coordonnées manuellement dans lineEdit
        self.lineEdit.textChanged.connect(self.clear_address_field_on_coord_change)

        
        #Saisir que des valeurs numériques dans le champ de coordonnées
        #regex = QtCore.QRegExp(r"[-+]?[\d\.,\s]+")
        #regex = QtCore.QRegExp(r"[\d\.\,\-\s]+")
        #regex = QtCore.QRegExp(r"(?!.*-.*-.*-)[\d\.\,\-\s]+")
        
        regex = QtCore.QRegExp(r"(?!.*-.*-.*-)(?!.*--)[\d\.\,\-\s]+")
        validator = QtGui.QRegExpValidator(regex, self)
    
        self.lineEdit.setValidator(validator)

        

    def toggle_time_distance_groups(self):
        """Active/désactive les groupes de champs (Temps ou Distance) en fonction du RadioButton sélectionné."""
        is_isochrone = self.radioButton_4.isChecked()
        self.groupBox_4.setEnabled(is_isochrone) # Active le temps si isochrone est sélectionné
        self.groupBox_5.setEnabled(self.radioButton_5.isChecked()) # Active la distance si isodistance est sélectionné

    def select_point_on_map(self):
        self.hide() 
        self.iface.mapCanvas().unsetMapTool(self.iface.mapCanvas().mapTool()) 
        
        self.point_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.point_tool.canvasClicked.connect(self.handle_point_selection)
        
        self.iface.mapCanvas().setMapTool(self.point_tool)
        
        iface.messageBar().pushMessage("Sélectionner Point", 
                                       "Cliquez sur la carte pour définir le point de départ.", 
                                       level=0)

    def handle_point_selection(self, point: QgsPointXY):
        """
        Gère le point sélectionné sur le canevas, le reprojette en EPSG:4326 
        et met à jour le champ de coordonnées.
        """
        self.iface.mapCanvas().unsetMapTool(self.point_tool)
        
        # --- Étape 1 : Définition des SCR ---
        # SCR source est celui du canevas
        crs_source = self.iface.mapCanvas().mapSettings().destinationCrs()
        # SCR cible est EPSG:4326 (standard pour les APIs web, WGS 84)
        crs_target = QgsCoordinateReferenceSystem("EPSG:4326")
        
        
        # --- Étape 2 : Reprojection ---
        
        # Créer l'objet de transformation
        transform = QgsCoordinateTransform(crs_source, crs_target, QgsProject.instance())
        
        # Reprojeter le point
        reprojected_point = transform.transform(point)
        
        lon = reprojected_point.x()
        lat = reprojected_point.y()
        
        # --- Étape 3 : Formatage de la précision (15 décimales) ---
        # Utilisation de la f-string avec une précision de 15 pour la longitude et la latitude
        coords_str = f"{lon:.15f},{lat:.15f}" 
        
        self.lineEdit.setText(coords_str) 

        self.lineEdit_2.clear() #Réinitialisation de adresse
        iface.messageBar().pushMessage("Succès", 
                                       f"Coordonnées de départ (EPSG:4326) : {coords_str}", 
                                       level=0)
        self.show()

    
    #Géocodage

    # Géocodage
    def search_address(self, source_lineEdit=None):
        """
        Gère la saisie ou la sélection d'une adresse et la géocode en coordonnées lon,lat.
        Si source_lineEdit est fourni, la recherche se fait sur son contenu.
        """
        # Si la fonction est appelée sans source, on suppose que l'utilisateur a mis des coordonnées dans lineEdit
        if source_lineEdit is None:
             # Dans ce cas, on vérifie juste que le lineEdit contient bien des coordonnées valides
             coords_text = self.lineEdit.text().strip()
             if ',' in coords_text and all(self._is_float(c) for c in coords_text.split(',')):
                 # Si c'est déjà des coordonnées valides, on ne fait rien
                 return
             # Sinon, c'est une erreur, ou c'est l'utilisateur qui tape une adresse dans le mauvais champ
             QMessageBox.warning(self.iface.mainWindow(), "Erreur de Saisie", 
                                 "Veuillez saisir les coordonnées (lon,lat) ou utiliser le champ d'adresse (si existant) pour la recherche.")
             return
             
        # --- CAS DE RECHERCHE D'ADRESSE ---
        
        search_text = source_lineEdit.text().strip()

        print(f"DEBUG SEARCH: Géocodage démarré pour : '{search_text}'")
        
        if not search_text or (',' in search_text and any(c.isdigit() for c in search_text.split(','))):
            # C'est vide ou l'utilisateur a tapé des coordonnées dans le champ adresse, on ignore
            return

        try:
            result_coords = self.api_service.geocode_address(search_text)
            
            if result_coords:
                lon = result_coords.x()
                lat = result_coords.y()
                coords_str = f"{lon:.15f},{lat:.15f}" 
                
                # 🚨 CORRECTION CLÉ : Les coordonnées sont TOUJOURS écrites dans self.lineEdit (le champ de l'API)
                self.lineEdit.setText(coords_str)
                # Le champ de l'adresse est effacé pour indiquer que le travail est fait
                source_lineEdit.clear() 
                
                #iface.messageBar().pushMessage("Succès Géocodage", f"Adresse trouvée: {coords_str} (copié dans le champ de coordonnées)", level=0)
            else:
                QMessageBox.warning(self.iface.mainWindow(), "Recherche d'Adresse", 
                                    f"Aucun résultat trouvé pour l'adresse: '{search_text}'.")

        except ConnectionError as e:
             QMessageBox.critical(self.iface.mainWindow(), "Erreur API Géocodage", str(e))
        except Exception as e:
             QMessageBox.critical(self.iface.mainWindow(), "Erreur Inattendue", f"Géocodage échoué : {e}")

    # Méthode utilitaire simple pour vérifier si une chaîne est un float
    def _is_float(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False


    def suggest_addresses(self, text: str):
        """
        Déclenche la recherche d'adresses en temps réel pour l'autocomplétion.
        """
        print(f"TEST CONNEXION : suggest_addresses est appelé avec le texte : '{text}'")

        if len(text) < 3 or (',' in text and any(c.isdigit() for c in text.split(','))):
            self.completer.setModel(None)
            return

        try:
            suggestions = self.api_service.autocomplete_address(text)

            model = QtCore.QStringListModel(suggestions)
            self.completer.setModel(model)

            # Force l'affichage si on a des résultats
            if suggestions:
                self.completer.complete()

        except ConnectionError as e:
            iface.messageBar().pushMessage("Erreur Autocomplétion", str(e), level=2)
        except Exception as e:
            iface.messageBar().pushMessage("Erreur Inattendue", f"Autocomplétion : {e}", level=2)
            
    
    # Limi

    # NOUVELLE MÉTHODE DE PONT
    def search_address_after_completion(self, index: int):
        """
        Déclenché lorsque l'utilisateur sélectionne une adresse dans le QCompleter.
        L'index n'est pas utilisé directement, on lit le texte final dans lineEdit_2.
        
        Note: Cette méthode résout le problème du double clic en assurant
        que le texte est bien dans le lineEdit_2 avant de géocoder.
        """
        # 1. Lire le texte final qui a été inséré dans le lineEdit_2 par le QCompleter
        selected_address = self.lineEdit_2.text()
        
        if selected_address:
            # 2. Utiliser ce texte pour géocoder
            # La méthode search_address va :
            #   a) Géocoder l'adresse.
            #   b) Écrire les coordonnées dans self.lineEdit.
            #   c) Effacer self.lineEdit_2.
            self.search_address(source_lineEdit=self.lineEdit_2)
        else:
            # Cela arrive si l'utilisateur clique sans qu'un texte final ne soit là.
            print("Aucune adresse valide sélectionnée pour le géocodage.")
        
    # NOUVELLE MÉTHODE pour la touche Entrée manuelle
    def search_address_from_lineEdit_2(self):
        """
        Déclenche le géocodage lorsque l'utilisateur appuie sur Entrée dans lineEdit_2.
        """
        print(f"DEBUG PONT : Entrée manuelle dans lineEdit_2.")
        self.search_address(source_lineEdit=self.lineEdit_2)

    #Effacer le champ d'adresse

    def clear_address_field_on_coord_change(self):
        """
        Efface le champ d'adresse (lineEdit_2) lorsque l'utilisateur modifie 
        manuellement le champ de coordonnées (lineEdit).
        """
        # On efface seulement si le champ d'adresse contient quelque chose.
        if self.lineEdit_2.text():
            self.lineEdit_2.clear()

    def collect_parameters(self) -> IsochroneParameters:
        """
        Collecte et valide les paramètres de l'interface utilisateur pour la requête isochrone.
        Lit les coordonnées uniquement dans self.lineEdit.
        """
        
        # 1. Vérification du choix Isochrone/Isodistance
        if not self.radioButton_4.isChecked() and not self.radioButton_5.isChecked():
            QMessageBox.warning(self.iface.mainWindow(), 
                                "Erreur de paramétrage", 
                                "Veuillez d'abord choisir Isochrone ou Isodistance.")
            self.show()
            self.raise_()
            return None
        
        # 2. Lecture et validation des coordonnées (dans self.lineEdit)
        point_coords = self.lineEdit.text().strip() 
        
        # Vérification du format des coordonnées (lon,lat)
        if not point_coords:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur de Coordonnées", 
                                 "Veuillez saisir des coordonnées (lon,lat) dans le champ ou les obtenir via la recherche d'adresse/clic sur carte.")
            self.show(); self.raise_()
            return None
            
        parts = point_coords.split(',')
        is_coords_valid = len(parts) == 2 and all(self._is_float(c.strip()) for c in parts)
        
        if not is_coords_valid:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur de Coordonnées", 
                                 f"Le format de coordonnées '{point_coords}' est invalide. Attendu : 'lon,lat' (ex: 2.3522,48.8566).")
            self.show(); self.raise_()
            return None


        # 3. Lecture des autres paramètres
        raw_direction = self.comboBox_2.currentText()
        profile = self.comboBox.currentText()
        bdtopo_name = self.comboBox_3.currentText()
        is_isochrone = self.radioButton_4.isChecked()
        
        # 4. Calcul de la valeur Temps ou Distance
        time_or_distance_value = 0.0
        if is_isochrone:
            time_h = self.spinBox.value()
            time_mn = self.spinBox_2.value()
            time_or_distance_value = float((time_h * 60) + time_mn) # En minutes (API attend des secondes)
        else:
            time_or_distance_value = self.doubleSpinBox.value() # En km (API attend des mètres)
        
        
        # 5. Mappage de la direction
        direction_mapping = {
            "Départ": "departure",
            "Arrivée": "arrival"
        }
        direction = direction_mapping.get(raw_direction)
        
        if not direction:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur Interne", 
                                 f"Valeur de direction ('{raw_direction}') non reconnue.")
            return None
        
        # 6. Gestion des Contraintes
        list_of_constraints: List[Dict] = [] 
        
        if not self.radioButton.isChecked(): 
            list_of_constraints.append({"constraintType": "banned", "key": "wayType", "operator": "=", "value": "autoroute"})
            
        if not self.radioButton_2.isChecked(): 
            list_of_constraints.append({"constraintType": "banned", "key": "wayType", "operator": "=", "value": "pont"})
            
        if not self.radioButton_3.isChecked(): 
            list_of_constraints.append({"constraintType": "banned", "key": "wayType", "operator": "=", "value": "tunnel"})
        
        
        # 7. Création de l'objet IsochroneParameters
        params = IsochroneParameters(
            point=point_coords, # Format validé : lon,lat
            direction=direction,
            profile=profile,
            constraints_list=list_of_constraints,
            
            # La classe IsochroneParameters doit gérer la conversion min/sec et km/m
            time_or_distance_value=time_or_distance_value, 
            is_isochrone=is_isochrone, 
            bdtopo_name=bdtopo_name 
        )
        return params


    def run_isochrone_calculation(self):
        """Coordination principale : collecte, valide, appelle l'API et affiche."""
        
        params = self.collect_parameters()
        
        if params is None: 
            return
        
        is_valid, msg = params.is_valid()
        
        if not is_valid:
            QMessageBox.warning(self.iface.mainWindow(), "Erreur de paramétrage", msg)

            self.show()
            self.raise_()
            return

        try:
            json_data = self.api_service.get_isochrone(params)
            self.load_isochrone_to_qgis(json_data, params)
            
        except ConnectionError as e:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur de Communication", str(e))
            #iface.messageBar().pushMessage("Échec", "Erreur lors de la requête isochrone.", level=2)
            self.show()
            self.raise_()
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur Inattendue", f"Traitement échoué : {e}")
            self.show()
            self.raise_()

    
    def reset_configuration(self):
        """Réinitialise tous les champs du formulaire à leurs valeurs par défaut."""
        
        # 1. Coordonnées et Direction
        #self.lineEdit.clear()
        self.lineEdit.setText("2.3522,48.8566")
        self.comboBox_2.setCurrentIndex(0) # Départ
        
        # 2. Mode de Transport et BD
        self.comboBox.setCurrentIndex(0) # car
        self.comboBox_3.setCurrentIndex(0) # bdtopo-valhalla
        
        # 3. Temps et Distance (Isochrone par défaut)
        self.radioButton_4.setChecked(True) # Isochrone
        self.spinBox.setValue(0) # Temps (Heures)
        self.spinBox_2.setValue(0) # Temps (Minutes)
        self.doubleSpinBox.setValue(0.0) # Distance (Km)


        # 4. Contraintes (Aucune autorisation par défaut)
        self.radioButton.setChecked(False) # Autoroute
        self.radioButton_2.setChecked(False) # Pont
        self.radioButton_3.setChecked(False) # Tunnel

        self.radioButton_4.setChecked(False) # isochrone
        self.radioButton_5.setChecked(False) # isodisance
        
        
        # Mise à jour de l'état des groupes de temps/distance
        #self.toggle_time_distance_groups() 

        # Informer l'utilisateur (Optionnel)
        #iface.messageBar().pushMessage("Réinitialisation", "La configuration du plugin a été réinitialisée.", level=0)



    def load_isochrone_to_qgis(self, data: Dict, params: IsochroneParameters):
        """
        Crée une couche vecteur en mémoire à partir de la réponse JSON de l'API.
        """
        
        # Initialisation par défaut de layer_name (pour éviter NameError)
        layer_name = "Nouvelle_Couche_Isochrone"
        
        if params.is_isochrone:
             cost_unit = "min"
             cost_value_display = params.cost_value / 60 
        else:
             cost_unit = "km"
             cost_value_display = params.cost_value / 1000 
             
        layer_name = f"{'Isochrone' if params.is_isochrone else 'Isodistance'} {params.profile} - {cost_value_display:.1f} {cost_unit} ({params.direction})"
        
        try:
            coords = data["geometry"]["coordinates"][0] 
            polygon = QgsGeometry.fromPolygonXY([[QgsPointXY(x, y) for x, y in coords]])

            vl = QgsVectorLayer("Polygon?crs=EPSG:4326", layer_name, "memory")
            pr = vl.dataProvider()

            pr.addAttributes([
                QgsField("costType", QVariant.String),
                QgsField("costValue", QVariant.Int),
                QgsField("profile", QVariant.String)
            ])
            vl.updateFields()

            feat = QgsFeature()
            feat.setGeometry(polygon)
            feat.setAttributes([
                data.get("costType"), 
                data.get("costValue"), 
                data.get("profile")
            ])
            pr.addFeatures([feat])
            vl.updateExtents()

            QgsProject.instance().addMapLayer(vl)
            
            iface.messageBar().pushMessage("Succès", f"Couche '{layer_name}' chargée (Couche Mémoire).", level=0)
            
            # --- NOUVELLE LOGIQUE DE ZOOM ROBUSTE SUR LA COUCHE ---
            
            layer_extent = vl.extent()
            canvas = self.iface.mapCanvas()
            
            # 1. Vérifier si la couche a une étendue significative
            if layer_extent.width() > 0.0001 and layer_extent.height() > 0.0001:
                
                # 2. Définir les systèmes de coordonnées
                crs_source = QgsCoordinateReferenceSystem("EPSG:4326")
                crs_target = canvas.mapSettings().destinationCrs()
                
                # 3. Créer l'objet de transformation
                transform = QgsCoordinateTransform(crs_source, crs_target, QgsProject.instance())
                
                # 4. Reprojeter l'étendue de la couche vers le SCR du canevas
                transformed_extent = transform.transform(layer_extent)
                
                # 5. Zoomer sur l'étendue transformée
                canvas.setExtent(transformed_extent)
                canvas.refresh()
                
            else:
                # Si l'étendue est trop petite/invalide, affiche un message d'information.
                # Nous ne zoomons plus sur le point, car c'est le problème que nous voulons éviter.
                iface.messageBar().pushMessage("Attention", 
                                               "Géométrie générée trop petite ou nulle pour zoomer automatiquement.", 
                                               level=1)
                
            # --- FIN DE LA LOGIQUE DE ZOOM ---

        except KeyError as e:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur de Traitement", 
                                 f"Format de réponse API inattendu. Clé manquante: {e}")
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Erreur de Chargement QGIS", 
                                 f"Impossible de créer la couche en mémoire: {e}")