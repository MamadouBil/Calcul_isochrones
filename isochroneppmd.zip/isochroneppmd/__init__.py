# Fichier : __init__.py

# L'import doit être en dehors de la fonction ou géré à l'intérieur de manière sécurisée.
# La fonction classFactory est la seule nécessaire ici.

def classFactory(iface):
    """Charge la classe principale de l'extension."""
    
    # Importation relative du module principal du plugin
    from .isochroneppmd import IsochronePlugin 
    
    # Instanciation de la classe principale
    return IsochronePlugin(iface)