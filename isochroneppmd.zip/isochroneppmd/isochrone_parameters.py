# Fichier : isochrone_parameters.py
import json
from typing import List, Dict, Tuple

class IsochroneParameters:
    """
    Modèle de données pour encapsuler et valider les paramètres de la requête isochrone/isodistance.
    """
    def __init__(self, 
                 point: str = "", 
                 direction: str = "departure",
                 profile: str = "", 
                 constraints_list: List[Dict] = None,
                 time_or_distance_value: float = 0.0, # Temps en min OU Distance en km (depuis l'interface)
                 is_isochrone: bool = True,           # True pour Isochrone (temps), False pour Isodistance (distance)
                 bdtopo_name: str = "bdtopo-valhalla" # Nom de la BD : valhalla ou pgr
                ):
        
        self.point = point
        self.direction = direction
        self.profile = profile
        self.constraints_list = constraints_list if constraints_list is not None else []
        
        # Attributs pour la flexibilité Isochrone/Isodistance et BD
        self.bdtopo_name = bdtopo_name
        self.is_isochrone = is_isochrone
        
        # Le service de Géoportail attend des SECONDES pour le temps et des MÈTRES (si l'URL est correcte) pour la distance
        if self.is_isochrone:
            # Temps total en minutes (time_or_distance_value) converti en secondes
            self.cost_value = int(time_or_distance_value * 60)
            self.cost_type = "time"
            self.cost_unit = "second"
        else:
            # Distance totale en km (depuis l'interface) convertie en MÈTRES (pour l'API)
            self.cost_value = time_or_distance_value * 1000 
            self.cost_type = "distance"
            self.cost_unit = "meter" # Unité utilisée dans l'API
            
        # Paramètres API fixes
        self.crs = "EPSG:4326"


    def is_valid(self) -> Tuple[bool, str]:
        """Vérifie que les paramètres minimaux sont présents."""
        
        coords = self.point.split(',')
        if len(coords) != 2 or not all(c.strip() for c in coords):
            return False, "Le point de départ est invalide (format attendu : lon,lat)."
            
        if self.cost_value <= 0:
            if self.is_isochrone:
                return False, "Le temps de parcours (isochrone) doit être supérieur à zéro mn."
            else:
                # On vérifie la valeur en mètres
                return False, "La distance de parcours (isodistance) doit être supérieure à zéro km."
            
        if not self.profile:
            return False, "Le mode de transport doit être sélectionné."
            
        return True, ""

    def get_api_params(self) -> Dict:
        """Retourne un dictionnaire des paramètres à passer à l'API."""
        
        params = {
            # 'resource' sera rempli par le bdtopo_name dans le service API
            'point': self.point,
            'direction': self.direction,
            'costType': self.cost_type,
            'costValue': self.cost_value,
            'profile': self.profile,
            'crs': self.crs,
        }
        
        # Ajouter le paramètre d'unité
        if self.is_isochrone:
            params['timeUnit'] = self.cost_unit
        else:
            params['distanceUnit'] = self.cost_unit
            
        return params