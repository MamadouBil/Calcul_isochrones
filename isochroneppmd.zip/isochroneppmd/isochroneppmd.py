# Fichier : isochroneppmd.py
import os
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction

from .isochroneppmd_dialog import IsochroneDialog 

class IsochronePlugin:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dialog = None 

    def initGui(self):
        """Initialisation de l'interface graphique."""
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(QIcon(icon_path), "Calculer Isochrone Géoplateforme", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        # Ajout du bouton à la barre d'outils et au menu
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Plugins", self.action)

    def unload(self):
        """Nettoyage lors du déchargement du plugin (CORRIGÉ pour QGIS 3.4)."""
        
        # 1. Retrait de l'icône de la barre d'outils
        self.iface.removeToolBarIcon(self.action)
        
        # 2. Retrait de l'action du menu Plugins
        try:
             self.iface.removePluginMenu("&Plugins", self.action)
        except AttributeError:
             pass 

    def run(self):
        """Affiche la boîte de dialogue du plugin."""
        if not self.dialog:
            self.dialog = IsochroneDialog(self.iface) 
        
        self.dialog.show()